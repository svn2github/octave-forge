function resu = display(df)

  %# function resu = display(df)
  %# Tries to produce a nicely formatted output of a dataframe.

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.
  
  %#
  %# $Id: display.m,v 1.5 2010-07-19 13:41:16 dupuis Exp $
  %#

%# generate header name
head = sprintf("Dataframe with %d rows and %d columns", df._cnt);

if all(df._cnt > 0), %# stop for empty df
  vspace = repmat(' ', df._cnt(1), 1);
  for indi=1:df._cnt(2),
    %# emit column names
    dummy{1, 2+indi} = deblank(disp(df._name{2}(indi, :)));
    dummy{2, 2+indi} = deblank(df._type{indi});
    %# "print" each column
    switch df._type{indi}
      case {'char'}
	indj = ~isprint(df._data{indi}); indk = find(indj);
	if ~isempty(indk), %# take care of special chars
	  tmp_str = cellstr(df._data{indi});
	  for indk = find(indj).',  
	    tmp_str{indk} = undo_string_escapes(tmp_str{indk});
	  endfor
	  df._data{indi} = char(tmp_str);
	endif
	%# keep the whole thing, and add a vertical space
	dummy{3, 2+indi} = disp(df._data{indi});    
	dummy{3, 2+indi} = horzcat...
	    (vspace, char(regexp(dummy{3, 2+indi}, '.*', ...
				 'match', 'dotexceptnewline')));
      otherwise
	%# keep only one horizontal space per line
	dummy{3, 2+indi} = disp(df._data{indi});
	tmp_str = char(regexp(dummy{3, 2+indi}, ' \S.*', ...
			      'match', 'dotexceptnewline'));
	if size(tmp_str, 1) < df._cnt(1),
	  tmp_str = horzcat...
	      (vspace, char(regexp(dummy{3, 2+indi}, '\S.*', ...
				   'match', 'dotexceptnewline')));
	endif
	dummy{3, 2+indi} = tmp_str;
    endswitch
  endfor

  vspace = [' '; ' '; vspace];
  %# second line content
  dummy{2, 1} = [" ";"Nr"];
  dummy{3, 1} = disp(df._ridx(:));
  %# emit row names
  if isempty(df._name{1}),
    dummy{2, 2} = []; dummy{3, 2} = [];
  else
    dummy{2, 2} = [" ";" "];
    dummy{3, 2} = disp(df._name{1});
  endif
  
  if size(dummy, 2) > 1,
    %# now, reassemble everything
    indi = regexp(dummy{3, 1}, '\b.*\b', 'match', 'dotexceptnewline');
    resu = strjust(char(dummy{2, 1}, indi), 'right');
    %# insert a vertical space
    if !isempty(dummy{3, 2}),
      indi = regexp(dummy{3, 2}, '.*', 'match', 'dotexceptnewline');
      if ~isempty(indi),
	resu = horzcat(resu, vspace);
	resu = horzcat(resu, strjust(char(dummy{2, 2}, indi), 'right'));
      endif
    endif
    
    %# emit each colum
    for indi = 1:df._cnt(2),  
      try
	%# avoid this column touching the previous one
	if any(cellfun('size', dummy(1:2, 2+indi), 2) >= ...
	       size(dummy{3, 2+indi}, 2)),
	  resu = horzcat(resu, vspace);
	endif
	resu = horzcat(resu, strjust(char(dummy{:, 2+indi}), 'right'));
      catch
	tmp_str = sprintf("Emitting %d lines, expecting %d", ...
			  size(dummy{3, 2+indi}, 1), df._cnt(1));
	error(tmp_str);
      end_try_catch
    endfor
  else
    resu = '';
  endif
else
  resu = '';
endif

resu = char(head, resu); disp(resu)


