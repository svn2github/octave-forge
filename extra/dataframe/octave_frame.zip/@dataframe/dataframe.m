function df = dataframe(x, varargin)

  %# function df = dataframe(x, ...)
  %#	This is the default constructor for a dataframe object, which is
  %#	similar to R data.frame. It's a way to group tabular data, then
  %#	accessing them either as matrix or by column name.
  %# Input argument x may be
  %# - a matrix => create column names from input name
  %# - a cell matrix => try to infer column names from the first row,
  %#   and row names from the first column
  %# - a file name => import data into a dataframe
  %# - a matrix of char => initialise colnames from them
  %# Variable input arguments:
  %# if one of them is the string 'rownames', the next argument is used
  %# as initialiser for row names. Otherwise, data are concatenanted to
  %# the existing ones.

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.

  %#
  %# $Id: dataframe.m,v 1.1 2010-07-15 14:13:14 dupuis Exp $
  %#

if 1 == nargin && isnull(x),
  %# default constructor: initialise the fields in the right order
  df._cnt = [0 0];
  df._name = cell(1, 2); 
  df._over = cell(1, 2);
  df._ridx = [];  
  df._data = cell(0, 0); 
  df._type = cell(0, 0);
  df = class(df, 'dataframe');
  return
endif

if 0 == nargin
  disp('FIXME -- should create a dataframe from the whole workspace')
  return
endif

if isa(x, 'dataframe')
  df = x;
else
  df = dataframe([]); %# get the right fields
endif

seeked = []; unquot = true; 

if length(varargin) > 0,
  indi = 1;
  %# loop over possible arguments
  while indi <= size(varargin, 2),
    switch(varargin{indi})
      case 'rownames'
	df._name{1} = char(varargin{indi+1});
	df._cnt(1) = size(df._name{1}, 1);
	varargin(indi:indi+1) = [];
      case 'colnames'
	df._name{2} = char(varargin{indi+1});
	df._cnt(2) = size(df._name{2}, 1);
	varargin(indi:indi+1) = [];
      case 'seeked',
	seeked = varargin{indi + 1};
	varargin(indi:indi+1) = [];
      case 'unquot',
	unquot = varargin{indi + 1};
	varargin(indi:indi+1) = [];
      otherwise %# FIXME: just skip it for now
	indi = indi + 1;
    endswitch
  endwhile
endif

indi = 0; 
while indi <= size(varargin, 2),
  indi = indi + 1;
  if ~isa(x, 'dataframe')
    if isa(x, 'char') && size(x, 1) < 2,
      %# read the data frame from a file
      try
	x = load(tilde_expand(x));
      catch
        UTF8_BOM = char([0xEF 0xBB 0xBF]);
	unwind_protect
	  fid = fopen(tilde_expand(x));
	  dummy = fgetl(fid);
	  if !strcmp(dummy, UTF8_BOM),
	    frewind(fid);
	  endif
	  in = fscanf(fid, "%c"); %# slurps everything
	unwind_protect_cleanup
	  fclose(fid);
	end_unwind_protect
	lines = regexp(in,'(^|\n)([^\n]+)', 'match'); %# cut into lines
	content = cellfun(@(x) regexp(x, '(\b|'')[^,]+(''|\b)', 'match'), ...
			  lines, 'UniformOutput', false); %# extract fields
	indl = 1; indj = 1; %# disp('line 151 '); keyboard
	if ~isempty(seeked),
	  while indl <= length(lines),
	    dummy = content{indl};
	    if strcmp(dummy{1}, seeked)
	      break;
	    endif
	    indl = indl + 1;
	  endwhile
	else
	  dummy = content{indl};
	endif
	x = cell(1+length(lines)-indl, size(dummy, 2)); 
	while indl <= length(lines),
	  dummy = content{indl};
	  %# try to convert to float
	  the_line = cellfun(@(x) sscanf(x, "%f"), dummy, ...
			     'UniformOutput', false);
	  for indk = 1: size(the_line, 2),
	    if isempty(the_line{indk}) || any(size(the_line{indk}) > 1), 
	      %#if indi > 1 && indk > 1, disp('line 117 '); keyboard; endif
	      if unquot,
		try
		  x(indj, indk) = regexp(dummy{indk}, '[^''].*[^'']', 'match'){1};
		catch
		  %# if the previous test fails, try a simpler one
		  in = regexp(dummy{indk}, '[^'']+', 'match');
		  if !isempty(in),
		    x(indj, indk) = in{1};
		  else
		    x(indj, indk) = [];
		  endif
		end_try_catch
	      else
		x(indj, indk) = dummy{indk}; %# no conversion possible
	      endif
	    else
	      x(indj, indk) = the_line{indk}; 
	    endif
	  endfor
	  indl = indl + 1; indj = indj + 1;
	endwhile
	clear UTF8_BOM fid in lines indl the_line content
      end_try_catch
    endif
    
    %# fallback, avoiding a recursive call
  
    idx.type = '()';
    indj = df._cnt(2)+(1:size(x, 2));
    idx.subs = {':', indj};
    %# preset colnames
    dummy = df_colnames(inputname(indi), indj);
    [df._name{2}, dummy] = df_strjust(df._name{2}, dummy);
    df._name{2}(indj, :) = dummy; df._over{2}(indj, 1) = true;
    %# use direct assignement
    df = subsasgn(df, idx, x);
  else
    if indi > 0,
      error('FIXME: concatenating dataframes');
    endif
  endif

  try
    %# loop over next variable argument
    x = varargin{1, indi};   
  catch
  end_try_catch

endwhile

endfunction

function x = df_colnames(base, num)
  %# small auxiliary function to generate column names. This is required
  %# here, as only the constructor can use inputname
  if 0 != index(base, "("),
    x = 'X';
  else
    x = base;
  endif

  if numel(num) > 1,
    x = repmat(x, numel(num), 1);
    x = cstrcat(x, strjust(num2str(num(:)), 'left'));
  endif
    
endfunction
