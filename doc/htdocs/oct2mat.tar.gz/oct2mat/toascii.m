function y=toascii(x)
  if isstr(x), y=x;
  else y=string(x);
  end
