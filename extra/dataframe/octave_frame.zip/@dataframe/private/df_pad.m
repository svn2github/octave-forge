function resu = df_pad(df, dim, n, coltype)
  %# function resu = df_pad(df, dim, n)
  %# given a dataframe, insert n rows or columns, and adjust everything
  %# accordingly

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.
  
  %#
  %# $Id: df_pad.m,v 1.2 2010-07-19 12:44:19 dupuis Exp $
  %#

  resu = df;
  if nargin < 4, coltype = 1; endif

  switch dim
    case 1
      if !isempty(df._name{1}),
	if size(df._name{1}, 1) < df._cnt(1)+n,
	  %# generate a name for the new row(s)
	  dummy = df._name{1};
	  dummy = char(dummy, repmat('_', n, size(dummy, 2)));
	  resu._name{1} = dummy;
	  df._over{1}(df._cnt(1)+(1:n), 1) = true;
	endif
      endif
      %# complete row indexes
      if isempty(df._ridx),
	dummy = (1:n).';
      else
	dummy = df._ridx;
	dummy = [dummy; dummy(end) + (1:n).'];
      endif
      resu._ridx = dummy;
      %# pad every line
      for indi = 1:df._cnt(2),
	switch df._type{indi}
	  case {'char'}
	    dummy = char(df._data{indi}, repmat('_', n, ...
						size(df._data{indi}, 2)));
	  case { 'double' }
	    dummy = vertcat(df._data{indi}, repmat(0, n, 1));
	  otherwise
	    dummy = cast(vertcat(df._data{indi}, repmat(0, n, 1)), ...
			 df._type{indi});
	endswitch
	resu._data{indi} = dummy;
      endfor
      resu._cnt(1) = df._cnt(1) + n;
    case 2
      %# create new columns
      for indi = df._cnt(2)+(1:n),
	switch coltype
	  case {'char'}
	    dummy = repmat('_', df._cnt(1), 1);
	  case { 'double' }
	    dummy = repmat(0, df._cnt(1), 1);
	  otherwise
	    dummy = cast(repmat(0, df._cnt(1), 1), coltype);
	endswitch
	resu._data{indi} = dummy;
	resu._type{indi} = coltype;
      endfor
      if size(df._name{2}, 1) < df._cnt(2)+n,
      	%# generate a name for the new column(s)
	dummy = cstrcat('_', strjust(num2str(df._cnt(2)+(1:n).'), 'left'));
	if isempty(resu._name{2}),
	  resu._name{2} = dummy;
	else
	  resu._name{2} = strjust(char(resu._name{2}, dummy), 'left');
	endif
	df_over{2}(df._cnt(2)+(1:n), 1) = true;
      endif
      resu._cnt(2) = df._cnt(2) + n;
    otherwise
      error('Invalid dimension in df_pad');
  endswitch

endfunction		
