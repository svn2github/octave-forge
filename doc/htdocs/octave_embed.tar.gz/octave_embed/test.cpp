#include <iostream>
#include "embed.h"

void myeval(const char *string)
{
  std::cout << "Eval <" << string << ">\n";
  octave_call(string);
  octave_call("disp('---------------------------');");
}

int main(int argc, char *argv[])
{
  // Puts error output into file
  //std::ofstream err("cerr.txt");
  //std::cerr.rdbuf(err.rdbuf());

  // Puts non-error output into file
  //std::ofstream err("cout.txt");
  //octave_stdout.rdbuf(err.rdbuf());

  octave_init(argc, argv);
  
  myeval("a = [1 2 3 4 5]");
  myeval("b = [1 2 3 4] ./ [4 4 0]");
  myeval("b 1.5");
  myeval("a = [1 2 3 4 5]");
  myeval("b = [1 2 3 4] ./ [4 4 0]");

  octave_exit();

  return 0;
}

