#!/bin/sh
# Copyright (C) 2007, Thomas Treichl and Paul Kienzle
# Copyright (C) 2008-2009, Thomas Treichl
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301 USA
set -euv

# This is the name of the file that is used for displaying outputs
# while configuring, compiling and installing. Use /dev/stdout to
# display all messages in the running terminal.
MSGFILE=/tmp/gnuplot.logfile # /dev/stdout

# This is the name of the directory where all dependencies are
# installed. The string "-ppc" or "-i386" is added to the end of the
# given pathname, eg. /tmp/abc becomes /tmp/abc-pcc etc.
TEMPDIR=/tmp/gnuplot

# This is the name of the directory where the dmg files are installed
# temporary before the compressed disc image file *.dmg file is
# created.
DMGDIR=/tmp/image

# These are the hyperlinks of the packages that are needed to build
# the Gnuplot.app with all its dependencies.
READLINEPACK=http://ftp.gnu.org/gnu/readline/readline-6.0.tar.gz
FREETYPEPACK=http://www.very-clever.com/download/nongnu/freetype/freetype-2.3.9.tar.gz
ZLIBPACK=http://switch.dl.sourceforge.net/sourceforge/libpng/zlib-1.2.3.tar.gz
LIBPNGPACK=http://switch.dl.sourceforge.net/sourceforge/libpng/libpng-1.2.29.tar.gz
LIBJPEGPACK=http://ftp.debian.org/debian/pool/main/libj/libjpeg6b/libjpeg6b_6b.orig.tar.gz
LIBJPEGDIFF=http://ftp.debian.org/debian/pool/main/libj/libjpeg6b/libjpeg6b_6b-13.diff.gz
LIBGDPACK=http://www.libgd.org/releases/gd-2.0.35.tar.gz
AQUATERMPACK=http://switch.dl.sourceforge.net/sourceforge/aquaterm/aquaterm_src.1.0.1.tar.gz
GNUPLOTPACK=http://heanet.dl.sourceforge.net/sourceforge/gnuplot/gnuplot-4.2.5.tar.gz
GNUPLOTPATCH=./gnuplot-4.2.5.diff

##########################################################################
#####                Don't modify anything downwards here            #####
##########################################################################

# Function:    evalfailexit
# Input args:  ${1} is the string that has to be evaluated
#              ${MSGFILE} is used for output of messages
# Output args: -
# Description: Evaluates the ${1} string, prints a message and exits on fail
evalfailexit() {
  if ( ! eval "${1} 2>&1 >>${MSGFILE}" ); then
    echo "makegnuplotapp.sh: Building gnuplot.app has failed"
    echo "The command that failed was"
    echo "  ${1}"
    exit 1
  fi
}

# Function:    getsource
# Input args:  ${1} is the web adress for the file that is downloaded
# Output args: -
# Description: Downloads the source file that is given as ${1}
getsource() {
    # Check if we do already have downloaded the ${1}.* file
    local vfile=${1##*/} # echo ${vfile}
    if [ ! -f ${vfile} ]; then
        echo "makegnuplotapp.sh: Downloading \"${vfile}\" ..."
        evalfailexit "curl -s -S ${1} -o ${vfile}"
    fi
}

# Function:    unpack
# Input args:  ${1} is the name of the file that has to be extracted
# Output args: -
# Description: Extracts the source file that is given as ${1}
unpack () {
    if [ ${1##*.tar.} == "gz" ]; then
        # We really do know that ${1}.tar.gz extracts to ${1}
        vlocal=${1%.tar.gz}
        if [ ! -d ${vlocal} ]; then
            echo "makegnuplotapp.sh: Extracting \"${1}\" ..."
            evalfailexit "tar -xzf ${1}"
        fi
    elif [ ${1##*.} == "dmg" ]; then
        echo "makegnuplotapp.sh: No implementation for \".dmg\" at the moment"
        exit 1
    fi
}

# Function:    confmakeinst
# Input args:  ${1} is the directory name for the sources
#              ${2} is the extra flags for configuration
# Output args: 
# Description: Configures, compiles and installs a source package
confmakeinst() {
  # if [ ! -f config.log ]; then
  echo "makegnuplotapp.sh: Configuring \"${1}\" ..."
  evalfailexit "./configure ${2}"
  # fi
  echo "makegnuplotapp.sh: Making \"${1}\" ..."
  evalfailexit "make"
  echo "makegnuplotapp.sh: Installing \"${1}\" ..."
  evalfailexit "make install"
}

##########################################################################
#####        Functions for building the Gnuplot dependencies         #####
##########################################################################

create_readline () {
  local vreadpack=${READLINEPACK##*/}   # echo ${vreadpack}
  local vreadfile=${vreadpack%.tar.gz*} # echo ${vfilename}

  getsource ${READLINEPACK}
  unpack ${vreadpack}
  cd ${vreadfile}
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  confmakeinst "${vreadfile}" "${1} --enable-static --disable-shared"
}

create_freetype () {
  local vfreepack=${FREETYPEPACK##*/}   # echo ${vfreepack}
  local vfreefile=${vfreepack%.tar.gz*} # echo ${vfilename}

  getsource ${FREETYPEPACK}
  unpack ${vfreepack}
  cd ${vfreefile}
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  confmakeinst "${vfreefile}" "${1} --enable-static --disable-shared"
}

create_zlib () {
  # The link /Developer/SDKs/MacOSX10.3.9.sdk/usr/lib/libz.dylib has
  # to be removed, otherwise the SDK internal libz is found and this
  # is a bug.
  local vlibzpack=${ZLIBPACK##*/}       # echo ${vlibzpack}
  local vlibzfile=${vlibzpack%.tar.gz*} # echo ${vlibzfile}

#  getsource ${ZLIBPACK}
#  unpack ${vlibzpack}
#  cd ${vlibzfile}
#  confmakeinst "${vlibzfile}" "${1} -static"

  getsource ${ZLIBPACK}
  unpack ${vlibzpack}

  echo "makegnuplotapp.sh: Configuring ${vlibzfile} ..."
  cd ${vlibzfile}
  export CC=${CC}
  export CFLAGS=${CFLAGS}
  export PREFIX=${TEMPDIR}
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  evalfailexit "./configure --prefix=${TEMPDIR}"
  echo "makegnuplotapp.sh: Making ${vlibzfile} ..."
  evalfailexit "${MAKE}"
  evalfailexit "make install"
  echo "makegnuplotapp.sh: Make install ${vlibzfile} ..."
  evalfailexit "install -c -S libz.a ${TEMPDIR}/lib"
  evalfailexit "install -c -S crc32.h inffast.h inflate.h trees.h zutil.h ${TEMPDIR}/include"
  evalfailexit "install -c -S deflate.h inffixed.h inftrees.h zconf.h zlib.h ${TEMPDIR}/include"
}

create_libpng () {
  local vpngpack=${LIBPNGPACK##*/}    # echo ${vpngpack}
  local vpngfile=${vpngpack%.tar.gz*} # echo ${vpngfile}

  getsource ${LIBPNGPACK}
  unpack ${vpngpack}
  cd ${vpngfile}
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  confmakeinst "${vpngfile}" "${1} --enable-static --disable-shared --with-binconfigs"
}

create_libjpeg () {
  local vjpegpack=${LIBJPEGPACK##*/}    # echo ${vjpegpack}
  local vjpegfile=${vjpegpack%.tar.gz*} # echo ${vjpegfile}
  local vjpegdiff=${LIBJPEGDIFF##*/}    # echo ${vjpegdiff}
  local vjpegdnam=${vjpegdiff%.gz*}     # echo ${vjpegdiff}

  getsource ${LIBJPEGPACK}
  getsource ${LIBJPEGDIFF}
  evalfailexit "rm -rf libjpeg6b-6b"

  unpack ${vjpegpack};
  evalfailexit "mv jpeg-6b libjpeg6b-6b"

  if ! [ -s ${vjpegdnam} ]; then
    echo "makegnuplotapp.sh: Extracting ${vjpegdiff} ..."
    evalfailexit "gunzip ${vjpegdiff}"
    echo "makegnuplotapp.sh: Applying patch ${vjpegdnam} ..."
    evalfailexit "patch -p0 < ${vjpegdnam}"
  fi

  cd libjpeg6b-6b # WATCH OUT cd MAY FAIL
  echo "makegnuplotapp.sh: Creating install directories ..."
  evalfailexit "install -d ${TEMPDIR}/{bin,man,man/man1,lib,include}"
  echo "makegnuplotapp.sh: Calling ./configure ..."
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  evalfailexit "./configure ${1}"
  echo "makegnuplotapp.sh: Making \"${vjpegfile}\" ..."
  evalfailexit "make"
  echo "makegnuplotapp.sh: Installing \"${vjpegfile}\" ..."
  evalfailexit "make install-lib"
}

create_gdlib () {

  # export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/texbin:/tmp/gnuplot-ppc/bin

  local vgdpack=${LIBGDPACK##*/}    # echo ${vgdpack}
  local vgdfile=${vgdpack%.tar.gz*} # echo ${vgdfile}

  # Watch out, in LDFLAGS the -isyslibroot isn't set. Compilation fails
  # if this would be set.
  LDFLAGS="${ARCH} -Wl,-headerpad_max_install_names -L${TEMPDIR}/lib"
  CONFFLAGS="CC=\"${CC}\" CPP=\"${CPP}\" CFLAGS=\"${CFLAGS}\" CPPFLAGS=\"${CPPFLAGS}\""
  CONFFLAGS="${CONFFLAGS} CXXFLAGS=\"${CXXFLAGS}\" LDFLAGS=\"${LDFLAGS}\""
  CONFFLAGS="${CONFFLAGS} --prefix=${TEMPDIR} ${BUILDARCH} --enable-static --disable-shared"

  getsource ${LIBGDPACK}
  unpack ${vgdpack}
  cd ${vgdfile}

  # This ugly implementation has been made because the freetype-config
  # of the compiled freetype may be found but not Apple's original
  # freetype config. If Apple's original freetype-config is found then
  # ./configure returns an error.
  if [ "${ARCH}" == "-arch i386" ]; then
    echo "makegnuplotapp.sh: FIXME hardcoded \$PATH variable is set ..."
    export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/texbin:/tmp/gnuplot-i386/bin
    export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
    confmakeinst "${vgdfile}" "${CONFFLAGS} CFLAGS=-I/Developer/SDKs/MacOSX10.4u.sdk/usr/X11R6/include"
  elif [ "${ARCH}" == "-arch ppc" ]; then
    echo "makegnuplotapp.sh: FIXME hardcoded \$PATH variable is set ..."
    export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/texbin:/tmp/gnuplot-ppc/bin
    export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
    confmakeinst "${vgdfile}" "${CONFFLAGS} CFLAGS=-I/Developer/SDKs/MacOSX10.3.9.sdk/usr/X11R6/include"
  else
    echo "makegnuplotapp.sh: Error before configuring gdlib"
    exit 1
  fi
}

create_aquaterm () {
  local vaquapack=${AQUATERMPACK##*/}   # echo ${vaquapack}
  local vaquafile=${vaquapack%.tar.gz*} # echo ${vaquafile}

  getsource ${AQUATERMPACK}
  unpack ${vaquapack}

  cd aquaterm # NOTE THAT THIS cd MAY FAIL
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  echo "makegnuplotapp.sh: Compiling AquaTerm ..."
  evalfailexit "xcodebuild -configuration Deployment -target AquaTerm"

  echo "makegnuplotapp.sh: Installing AquaTerm ..."
  evalfailexit "cp -rp ./build/Deployment/AquaTerm.app ${TEMPDIR}/lib"
  evalfailexit "cp -rp ./build/Deployment/AquaTerm.framework ${TEMPDIR}/lib"
  evalfailexit "ln -sfv  ${TEMPDIR}/lib/AquaTerm.framework/Versions/A/AquaTerm ${TEMPDIR}/lib/libaquaterm.1.0.1.dylib"
  evalfailexit "rm -rf ${TEMPDIR}/lib/libaquaterm.1.0.0.dylib"
  evalfailexit "ln -sfv  ${TEMPDIR}/lib/libaquaterm.1.0.1.dylib ${TEMPDIR}/lib/libaquaterm.1.0.0.dylib"
  evalfailexit "rm -rf ${TEMPDIR}/lib/libaquaterm.dylib"
  evalfailexit "ln -sfv  ${TEMPDIR}/lib/libaquaterm.1.0.1.dylib ${TEMPDIR}/lib/libaquaterm.dylib"
  evalfailexit "install -d ${TEMPDIR}/include/aquaterm"
  evalfailexit "ln -sfv  ${TEMPDIR}/lib/AquaTerm.framework/Versions/A/Headers/AQTAdapter.h ${TEMPDIR}/include/aquaterm"
  evalfailexit "ln -sfv  ${TEMPDIR}/lib/AquaTerm.framework/Versions/A/Headers/aquaterm.h ${TEMPDIR}/include/aquaterm"
}

create_gnuplot () {
  local vplotpack=${GNUPLOTPACK##*/}    # echo ${vplotpack}
  local vplotfile=${vplotpack%.tar.gz*} # echo ${vplotfile}

  evalfailexit "rm -rf ${vplotfile}"
  getsource ${GNUPLOTPACK}
  unpack ${vplotpack}
  evalfailexit "patch -p0 < ${GNUPLOTPATCH}"
  cd ${vplotfile}
  export MACOSX_DEPLOYMENT_TARGET=${MACOSX_DEPLOYMENT_TARGET}
  evalfailexit "autoreconf"
  confmakeinst "${vplotfile}" "${1} --without-tutorial --with-readline=${TEMPDIR}"
}

create_plotapp() {
  local vplotpack=${GNUPLOTPACK##*/}    # echo ${vplotpack}
  local vplotfile=${vplotpack%.tar.gz*} # echo ${vplotfile}
  local vplotvers=${vplotfile##*-}      # echo ${vplotvers}
  local vplotshrt=${vplotvers%.*}       # echo ${vplotshrt}

  echo "makegnuplotapp.sh: Creating Gnuplot application ..."
  evalfailexit "rm -rf ${DMGDIR}" 
  evalfailexit "install -d ${DMGDIR}"

  # This routine creates a string of the form "-f <dir1> -f <dir2>" etc.
  # of all directories in ${TEMPDIR}
  PLATYFFLAG="";
  for DIRS in ${TEMPDIR}/*; do
    PLATYFFLAG="${PLATYFFLAG} -f ${DIRS}"
  done

  # cf. http://www.sveinbjorn.org/files/manpages/platypus.man.pdf
  evalfailexit "platypus -a Gnuplot.app -t shell -V ${vplotvers} \
    -u \"Thomas Williams, Colin Kelley, Russell Lang, Dave Kotz, John Campbell, \
    Gershon Elber, Alexander Woo and many others\" ${PLATYFFLAG} \
    -I info.gnuplot -R ./startup.sh ${DMGDIR}/Gnuplot.app"

  # Workaround for the missing -i option of platypus. Install icon by hand
  echo "makegnuplotapp.sh: Installing gnuplot icon ..."
  evalfailexit "install -c -S -m 777 ./gnuplot.icns \
    ${DMGDIR}/Gnuplot.app/Contents/Resources/appIcon.icns"

  # Removing all static libraries in Gnuplot.app
  echo "makegnuplotapp.sh: Removing static libraries ..."
  evalfailexit "rm -rf ${DMGDIR}/Gnuplot.app/Contents/Resources/lib/*.{la,a,old}"

  # Move gnuplot to gnuplot -%VERSION% and install local startup script
  local vbindir=${DMGDIR}/Gnuplot.app/Contents/Resources/bin
  evalfailexit "mv ${vbindir}/gnuplot ${vbindir}/gnuplot-${vplotvers}"

  echo "makegnuplotapp.sh: Removing special strings in gnuplot ..."
  sed -e "s:%VERSION%:${vplotvers}:g" \
      -e "s:%ARCH%:${ARCH}:g" \
      -e "s:%SHORTVER%:${vplotshrt}:g" gnuplot.in > ${vbindir}/gnuplot
  evalfailexit "chmod 777 ${vbindir}/gnuplot"
}

create_plotdoc() {
  local vplotpack=${GNUPLOTPACK##*/}    # echo ${vplotpack}
  local vplotfile=${vplotpack%.tar.gz*} # echo ${vplotfile}

  export DYLD_FRAMEWORK_PATH=${TEMPDIR}/lib

  cd ${vplotfile}
  echo "makegnuplotapp.sh: Installing Gnuplot manuals ..."
  evalfailexit "make ps"
  evalfailexit "install -d ${DMGDIR}/Docs"
  evalfailexit "ps2pdf14 ./docs/gnuplot.ps ${DMGDIR}/Docs/gnuplot.pdf"
  evalfailexit "ps2pdf14 ./docs/gpcard.ps ${DMGDIR}/Docs/gpcard.pdf"
  evalfailexit "ps2pdf14 ./tutorial/tutorial.ps ${DMGDIR}/Docs/tutorial.pdf"
  # Seems to be very out-of-date to me ...
  # evalfailexit "install -c -S -m 666 {FAQ,README,Copyright} ${DMGDIR}/Docs"
  evalfailexit "cp -rp demo ${DMGDIR}/Docs/Demo"
  cd ..
}

create_dmgfile() {
  local vplotpack=${GNUPLOTPACK##*/}    # echo ${vplotpack}
  local vplotfile=${vplotpack%.tar.gz*} # echo ${vplotfile}
  local vplotvers=${vplotfile##*-}      # echo ${vplotvers}
  local vplotarch=${TEMPDIR##*-}        # echo ${vplotarch}
  local DATE=`date`

  echo "makegnuplotapp.sh: Creating Readme.html file from Readme.texi ..."
  evalfailexit "LANGUAGE=en makeinfo --html --no-split Readme.texi -o Readme.html.in"
  sed -e "s/%VERSION%/${vplotvers}/g" \
      -e "s/%ARCH%/${vplotarch}/g" Readme.html.in > Readme.html

  echo "makegnuplotapp.sh: Installing extras in ${DMGDIR} ..."
  evalfailexit "install -c -S -m 333 Readme.html ${DMGDIR}/Readme.html"
  evalfailexit "install -c -S -m 333 _DS_Store_Main ${DMGDIR}/.DS_Store"
  evalfailexit "install -c -S -m 333 _DS_Store_Doc ${DMGDIR}/Docs/.DS_Store"
  evalfailexit "install -c -S -m 333 _background.png ${DMGDIR}/.background.png"
  evalfailexit "ln -sfv /Applications ${DMGDIR}/Applications"

  echo "makegnuplotapp.sh: Packing dmg compressed disk ..."
  evalfailexit "rm -rf ./gnuplot-${vplotvers}-${vplotarch}.dmg"
  evalfailexit "hdiutil create -volname gnuplot -fs HFS+ \
    -srcfolder ${DMGDIR} ./gnuplot-${vplotvers}-${vplotarch}.dmg"
}

# This is the main bash routine
if [ $# -ne 2 ]; then
    echo "Usage: makegnuplotapp.sh PACKAGE ARCH"
    exit 1
else
  case "${2}" in
    --ppc)
      TEMPDIR=${TEMPDIR}-ppc
      ARCH="-arch ppc"
      BUILDARCH="--host=powerpc-apple-darwin7.9.1"
      MACOSX_DEPLOYMENT_TARGET=10.3
      # OPTFLAGS="-O3 -ftree-vectorize -mpowerpc -mabi=altivec"
      OPTFLAGS="-O3 -mpowerpc -faltivec -maltivec -mabi=altivec"

      CC="gcc ${ARCH} ${OPTFLAGS}"
      CPP="${CC} -E"
      CXX="g++ ${ARCH} ${OPTFLAGS}"

      CFLAGS="-isysroot /Developer/SDKs/MacOSX10.3.9.sdk -I${TEMPDIR}/include"
      CPPFLAGS="${CFLAGS}"
      CXXFLAGS="${CFLAGS}"
      LDFLAGS="-Wl,-headerpad_max_install_names -Wl,-syslibroot -Wl,/Developer/SDKs/MacOSX10.3.9.sdk -L${TEMPDIR}/lib"
      ;;

    --i386)
      TEMPDIR=${TEMPDIR}-i386
      ARCH="-arch i386"
      BUILDARCH="--host=i386-apple-darwin8.11.1"
      MACOSX_DEPLOYMENT_TARGET=10.4
      OPTFLAGS="-O3 -fforce-addr -march=i686 -mfpmath=sse,387 -mieee-fp -msse3 -msse2 -msse -mmmx"

      CC="gcc ${ARCH} ${OPTFLAGS}"
      CPP="${CC} -E"
      CXX="g++ ${ARCH} ${OPTFLAGS}"

      CFLAGS="-isysroot /Developer/SDKs/MacOSX10.4u.sdk -I${TEMPDIR}/include"
      CPPFLAGS="${CFLAGS}"
      CXXFLAGS="${CFLAGS}"
      LDFLAGS="-Wl,-headerpad_max_install_names -Wl,-syslibroot -Wl,/Developer/SDKs/MacOSX10.4u.sdk -L${TEMPDIR}/lib"
      ;;

    *)
      echo "makegnuplotapp.sh: Unknown input argument ${2}"
      exit 1
      ;;

  esac

  CONFFLAGS="CC=\"${CC}\" CPP=\"${CPP}\" CXX=\"${CXX}\""
  CONFFLAGS="${CONFFLAGS} CFLAGS=\"${CFLAGS}\" CPPFLAGS=\"${CPPFLAGS}\""
  CONFFLAGS="${CONFFLAGS} CXXFLAGS=\"${CXXFLAGS}\" LDFLAGS=\"${LDFLAGS}\""
  CONFFLAGS="${CONFFLAGS} --prefix=${TEMPDIR} ${BUILDARCH}"

  MAKE="make"
  export PATH="${TEMPDIR}/bin:${PATH}"
  export DYLD_FRAMEWORK_PATH="${TEMPDIR}/lib"

  case "${1}" in
    --readline)
      create_readline "${CONFFLAGS}"
      ;;

    --freetype)
      create_freetype "${CONFFLAGS}"
    ;;

    --zlib)
      create_zlib "${CONFFLAGS}"
      ;;

    --libpng)
      create_libpng "${CONFFLAGS}"
      ;;

    --libjpeg)
      create_libjpeg "${CONFFLAGS}"
      ;;

    --gdlib)
      create_gdlib "${CONFFLAGS}"
      ;;

    --aquaterm)
      create_aquaterm "${CONFFLAGS}"
      ;;

    --gnuplot)
      create_gnuplot "${CONFFLAGS}"
      ;;

    --dmgimage)
      create_plotapp
      create_plotdoc
      create_dmgfile
      ;;

    --all)
      # Calling this script again and again to make sure that all
      # settings have been deleted that were set for the library or
      # the binary that has been compiled before...
      evalfailexit "./makegnuplotapp.sh --readline ${2}"
      evalfailexit "./makegnuplotapp.sh --freetype ${2}"
      evalfailexit "./makegnuplotapp.sh --zlib ${2}"
      evalfailexit "./makegnuplotapp.sh --libpng ${2}"
      evalfailexit "./makegnuplotapp.sh --libjpeg ${2}"
      evalfailexit "./makegnuplotapp.sh --gdlib ${2}"
      evalfailexit "./makegnuplotapp.sh --aquaterm ${2}"
      evalfailexit "./makegnuplotapp.sh --gnuplot ${2}"
      evalfailexit "./makegnuplotapp.sh --dmgimage ${2}"
      ;;

    *)
      echo "makegnuplotapp.sh: Unknown input argument ${1}"
      exit 1
      ;;

  esac
fi
