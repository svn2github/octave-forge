function oneplot
  set(gcf,'NextPlot','replace');