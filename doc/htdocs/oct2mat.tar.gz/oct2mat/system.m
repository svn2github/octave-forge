function x=system(command)
  [s,x]=unix(command);
