function [a, b] = df_strjust(a, b)
  
  %# small auxiliary function: make two char arrays the same width

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.
  
  %#
  %# $Id: df_strjust.m,v 1.1 2010-07-15 14:32:03 dupuis Exp $
  %#

  indi = size(a, 2) - size(b, 2);
  if indi < 0
    a = horzcat(repmat(' ', size(a, 1), -indi), a);
  elseif indi > 0,
    b = horzcat(repmat(' ', size(b, 1), indi), b);
  endif

endfunction
