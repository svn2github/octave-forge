function y = substr(s, i, j)
     y = s(i:i+j-1);
