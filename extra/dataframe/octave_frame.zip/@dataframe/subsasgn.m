function resu = subasgn(df, S, RHS)
  %# function resu = subasgn(df, S, RHS)
  %# This is the assignement operator for a dataframe object, taking
  %# care of all the housekeeping of meta-info.

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.
  
  %#
  %# $Id: subsasgn.m,v 1.9 2010-07-20 17:54:22 dupuis Exp $
  %#

  switch(S(1).type)
    case '{}'
      error('Invalid dataframe as cell assignement');
    case '.'
      resu = df;
      %# translate the external to internal name
      switch S(1).subs
	case "rownames"
	  if isnull(RHS),
	    if 1 == length(S),
	      resu._name{1} = '';
	    else
	      resu._name{1} = df_check_char_array(resu._name{1}, df._cnt(1));
	      if strcmp(S(2).type, '()') && strcmp(S(2).subs{2}, ':'),
		RHS = ' '; %# blank -- don't remove a whole line
	      endif
	      resu._name{1} = builtin('subsasgn', resu._name{1}, S(2:end), RHS);
	    endif
	  else
	    if numel(RHS) > 1,
	      %# make sure the two strings are the same width
	      [resu._name{1}, RHS] =  df_strjust(resu._name{1}, RHS);
	    endif
	    resu._name{1} = df_check_char_array(resu._name{1}, df._cnt(1));
	    if 1 == length(S), %# direct assignement
	      resu._name{1} = RHS;
	    else
	      resu._name{1} = builtin('subsasgn', resu._name{1}, S(2:end), RHS);
	    endif
	  endif
	  return
	case "colnames"
	  if isnull(RHS),  
	    if 1 == length(S),
	      resu._name{2} = '';
	    else
	      resu._name{2} = df_check_char_array(resu._name{2}, df._cnt(2));
	      if strcmp(S(2).type, '()') && strcmp(S(2).subs{2}, ':'),
		RHS = ' '; %# blank -- don't remove a whole line
	      endif
	      resu._name{2} = builtin('subsasgn', resu._name{2}, S(2:end), RHS);
	    endif
	  else
	    if numel(RHS) > 1,
	      %# make sure the two strings are the same width
	      [resu._name{2}, RHS] =  df_strjust(resu._name{2}, RHS);
	    endif
	    resu._name{2} = df_check_char_array(resu._name{2}, df._cnt(2));
	    if 1 == length(S), %# direct assignement
	      resu._name{2} = RHS;
	    else
	      resu._name{2} = builtin('subsasgn', resu._name{2}, S(2:end), RHS);
	    endif
	  endif
	  return
	  
	case "types"
	  if isnull(RHS)
	    error("Types can't be nulled");
	  endif
	  if 1 == length(S),
	    for indi = 1:df_cnt(2),
	      %# perform explicit cast on each column
	      resu._data{indi} = cast(resu._data{indi}, RHS);
	      resu._type{indi} = RHS;
	    endfor
	  else
	    if !strcmp(S(2).type, '{}'),
	      error("Invalid cell access");
	    endif 
	    if length(S) > 2,
	      error("Types can only be changed as a whole");
	    endif
	    indj = S(2).subs{};
	    if isa(indj, 'char'),
	      [indj, ncol] = df_name2idx(df._name{2}, indj, df._cnt(2));
	    endif
	    for indi = 1:length(indj),
	      %# perform explicit cast on selected columns
	      resu._data{indj(indi)} = cast(resu._data{indj(indi)}, RHS);
	      resu._type{indj(indi)} = RHS;
	    endfor 
	  endif
	  return
	  
	otherwise
	  if isa(S(1).subs, 'char')
	    [indc, ncol] = df_name2idx(df._name{2}, S(1).subs, df._cnt(2));
    	    if isempty(indc),
	      error("Do not modify directly a dataframe");
	    else
	      if 1 == length(S),
		indr = 1:df._cnt(1); nrow = df._cnt(1); %# select all lines
	      else
		[indr, nrow] = df_name2idx(df._name{1}, S(2).subs{1, 1},...
					   df._cnt(1));
	      endif
	      resu = df_matassign(df, indr, nrow, indc, ncol, RHS);
	    endif
	  else
	    error("Do not modify directly a dataframe");
	  endif
      endswitch
      
    case '()'
      [indr, nrow] = df_name2idx(df._name{1}, S(1).subs{1, 1}, df._cnt(1));
      [indc, ncol] = df_name2idx(df._name{2}, S(1).subs{1, 2}, df._cnt(2));
      resu = df_matassign(df, indr, nrow, indc, ncol, RHS);
 
  endswitch
  
  %# disp("end of subasgn"); keyboard
  
endfunction

function df = df_matassign(df, indr, nrow, indc, ncol, RHS)
  %# auxiliary function: assign the dataframe as if it was a matrix
  if isnull(RHS),
    if all([length(indr) length(indc)] < df._cnt),
      error("A null assignment can only have one non-colon index.");
    endif
    if length(indr) == df._cnt(1), %# removing column
      df._name{2}(indc, :) = []; df._over{2}(indc) = [];
      dummy = 1:df._cnt(2); dummy(indc) = [];
      df._type = df._type(dummy);
      df._data = df._data(dummy);
      df._cnt(2) = df._cnt(2) - length(indc);
    else
      df._name{1}(indr, :) = []; df._over{1}(indr) = [];
      df._ridx(indr) = [];
      %# to remove a line, iterate on each column
      for indi = 1:df._cnt(2),
	dummy =  df._data{indi};
	dummy(indr) = [];
	df._data{indi} = dummy;
      endfor
      df._cnt(1) = df._cnt(1) - length(indr);
    endif
    return;
  endif
  
  indc_was_set = ~isempty(indc);
  if ~indc_was_set, %# initial dataframe was empty
    ncol = size(RHS, 2); indc = 1:ncol;
  endif
  indr_was_set = ~isempty(indr);
  if ~indr_was_set, %# initial dataframe was empty
    nrow = size(RHS, 1); indr = 1:nrow;
  endif
  rname = cell(0,0); rname_width = max(1, size(df._name{2}, 2)); 
  ridx = []; cname = rname; ctype = rname;
  
  if iscell(RHS),
    if (length(indc) == df._cnt(2) && size(RHS, 2) >=  df._cnt(2))...
	  || 0 == df._cnt(2),
      %# providing too much information -- remove extra content
      if size(RHS, 1) > 1,
	%# at this stage, verify that the first line doesn't contain
	%# chars only; use them for column names
	dummy = cellfun('class', ...
			RHS(1, ~cellfun('isempty', RHS(1, :))), ...
			'UniformOutput', false);
	dummy = strcmp(dummy, 'char');
	if all(dummy),
	  if length(df._over{2}) >= max(indc) && ...
		!all(df._over{2}(indc)),
	    warning("Trying to overwrite colum names");
	  endif
	  cname = RHS(1, :); RHS = RHS(2:end, :);
	  if ~indr_was_set, 
	    nrow = nrow - 1; indr = 1:nrow;
	  endif
	endif
	%# at this stage, verify that the first line doesn't contain
	%# chars only; use them for column types
	dummy = cellfun('class', ...
			RHS(1, ~cellfun('isempty', RHS(1, :))), ...
			'UniformOutput', false);
	dummy = strcmp(dummy, 'char');
	if all(dummy),
	  if length(df._over{2}) >= max(indc) && ...
		!all(df._over{2}(indc)),
	    warning("Trying to overwrite colum names");
	  endif
	  ctype = RHS(1, :); RHS = RHS(2:end, :);
	  if ~indr_was_set, 
	    nrow = nrow - 1; indr = 1:nrow;
	  endif
	endif
      endif
      
      %# more elements than df width -- try to use the first two as
      %# row index and/or row name
      if size(RHS, 1) > 1,
	dummy = all(cellfun('isnumeric', ...
			    RHS(~cellfun('isempty', RHS(:, 1)), 1)));
      else
	dummy =  isnumeric(RHS{1, 1});
      endif
      dummy = dummy && (isempty(cname) || size(cname{1}, 2) < 1);
      if dummy,
	ridx = RHS(:, 1); RHS = RHS(:, 2:end);
	if !isempty(df._name{2}) && ...
	      size(df._name{2}, 1) == df._cnt(2) + ncol,
	  %# columns name were pre-filled with too much values
	  df._name{2}(end, :) = [];
	  df._over{2}(end) = [];
	  if size(RHS, 2) < ncol, 
	    ncol = size(RHS, 2); indc = 1:ncol;
	  endif
	elseif !indc_was_set, 
	  ncol = ncol - 1;  indc = 1:ncol; 
	endif 
	if !isempty(cname), cname = cname(2:end); endif
	if !isempty(ctype), ctype = ctype(2:end); endif
      endif

      if size(RHS, 2) >  df._cnt(2),
	%# verify the the first row doesn't contain chars only, use them
	%# for row names
	dummy = cellfun('class', ...
			RHS(~cellfun('isempty', RHS(:, 1)), 1), ...
			'UniformOutput', false);
	dummy = strcmp(dummy, 'char');
	if all(dummy), 
	  if length(df._over{1}) >= max(indr) && ...
		!all(df._over{1}(indr)),
	    warning("Trying to overwrite row names");
	  else
	    rname = RHS(:, 1); 
	  endif
	  rname_width = max([1; cellfun('size', rname, 2)]); 
	  RHS = RHS(:, 2:end); 
	  if !isempty(df._name{2}) && ...
		size(df._name{2}, 1) == df._cnt(2) + ncol,
	    %# columns name were pre-filled with too much values
	    df._name{2}(end, :) = [];
	    df._over{2}(end) = [];
	    if size(RHS, 2) < ncol, 
	      ncol = size(RHS, 2); indc = 1:ncol;
	    endif
	  elseif !indc_was_set, 
	    ncol = ncol - 1;  indc = 1:ncol; 
	  endif
	  if !isempty(cname), cname = cname(2:end); endif
	  if !isempty(ctype), ctype = ctype(2:end); endif
	endif
      endif
    endif
  endif
  
  %# perform row resizing now
  if max(indr) > df._cnt(1),
    df = df_pad(df, 1, max(indr)-df._cnt(1), rname_width);
  endif
  
  if iscell(RHS), %# we must pad on a column-by-column basis
    %# verify that each cell contains a non-empty vector, and that sizes
    %# are compatible
    dummy = cellfun('size', RHS(:), 2);
    if any(dummy < 1),
      error("cells content may not be empty");
    endif
    if any(dummy > 1),
      dummy = cellfun('class', RHS(dummy > 1), 'UniformOutput', false);
      dummy = strcmp(dummy, 'char');
      if any(0 == dummy),
	if 1 == size(RHS, 1),
	  error("cells may only contain column vectors");
	else
	  error("cells may only contain scalar");
	endif
      endif
    endif
    
    dummy = cellfun('size', RHS, 1);
    if any(dummy < 1),
      error("cells content may not be empty");
    endif
    if any(diff(dummy) > 0),
      error("cells content with unequal length");
    endif
    if 1 < size(RHS, 1) && any(dummy > 1),
      error("cells may only contain scalar");
    endif
    
    %# the real assignement
    if 1 == size(RHS, 1), %# each cell contains one vector
      fillfunc = @(x) RHS{x};
    else %# use cell2mat to pad on a column-by-column basis
      fillfunc = @(x) cell2mat(RHS(:, x));
    endif
    indj = 1; 
    for indi = 1:ncol,
      if indc(indi) > df._cnt(2),
	%# perform dynamic resizing one-by-one, to get type right
	if isempty(ctype) || length(ctype) < indc(indi),
	  df = df_pad(df, 2, indc(indi)-df._cnt(2), class(RHS{1, indj}));
	else
	  df = df_pad(df, 2, indc(indi)-df._cnt(2), ctype{indj});
	endif
      endif
      dummy = df._data{indc(indi)};
      try     
	switch df._type{indc(indi)}
	  case {'char' }
	    dummy = df_strset(dummy, indr, char(RHS(:, indj)));
	  case {'double' }
	    dummy(indr) = fillfunc(indj);
	  otherwise
	    dummy(indr) = fillfunc(indj);
	    dummy = cast(dummy, df._type{indc(indi)});
	endswitch
      catch
	dummy = ...
	    sprintf("Assignement failed for colum %d, of type %s and length %d,\nwith new content\n%s", ...
		    indj, df._type{indc(indi)}, length(indr), disp(RHS(:, indj)));
	error(dummy);
      end_try_catch
      df._data{indc(indi)} = dummy; indj = indj + 1;
    endfor
    
  else %# RHS is homogenous, pad at once
    if any(indc > df._cnt(2)),
      df = df_pad(df, 2, max(indc-df._cnt(2)), class(RHS));
    endif
    if numel(RHS) < 2 && ncol > 1,
      RHS = repmat(RHS, 1, ncol); %# if RHS is scalar, avoid
      %# errors if trying to get nth column
    endif
    indj = 1; for indi = 1:length(indc),
      dummy = df._data{indc(indi)};
      dummy(indr) = RHS(:, indj); 
      df._data{indc(indi)} = dummy; indj = indj + 1;
    endfor
  endif
  
  %# adjust ridx and rnames, if required
  if !isempty(ridx),
    dummy = df._ridx;
    if 1 == size(RHS, 1),
      dummy(indr) = ridx{1};
    else
      for indi = 1:nrow,
	dummy(indr(indi)) = ridx{indi};
      endfor
    endif
    if length(unique(dummy)) != length(dummy), %# || ...
	  %# any(diff(dummy) <= 0),
      error("row indexes are not unique or not ordered");
    endif
    df._ridx = dummy;
  endif
  if !isempty(rname) && (length(df._over{1}) < max(indr) || ...
	all(df._over{1}(indr))),
    df._name{1} = df_strset(df._name{1}, indr, char(rname));
    df._over{1}(indr) = false;
  endif
  if !isempty(cname) && (length(df._over{2}) < max(indc) || ...
	all(df._over{2}(indc))),
    df._name{2} = df_strset(df._name{2}, indc, char(cname));
    df._over{2}(indc) = false;
  endif
  
  %# catch
  %#   dummy = lasterr();
  %#   if isempty(dummy),
  %# 	error("Not enough values in RHS");
  %#   else
  %# 	error(dummy);
  %#   endif
  %# end_try_catch
  %# else
  %#   keyboard
  %#   error("either row, either column index empty  - should not happen");
  %# endif
  
endfunction
