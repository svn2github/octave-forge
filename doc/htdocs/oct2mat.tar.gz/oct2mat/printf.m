function printf(varargin)
	fprintf(1,varargin);
