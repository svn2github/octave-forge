function resu = cat(dim, A, varargin)
  %# function resu = cat(dim, A, varargin)
  %# This is the concatenation operator for a dataframe object. It is
  %# not yet really useable, as we must define how to concatenate two
  %# dataframes.

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.
  
  %#
  %# $Id: cat.m,v 1.1 2010-07-15 13:51:31 dupuis Exp $
  %#

  switch dim
    case 1
      resu = A;
      if size(resu._name{1}, 1) < resu._cnt(1),
	resu._name{1} = char(resu._name{1}, ...
			     repmat('', resu._cnt(1)-size(resu._name{1}, 1), 1));
      endif
      
      for indi=1:length(varargin),
	B = varargin{indi};
	if resu.cnt(2) != B.cnt(2),
	  error('Different number of columns in dataframes');
	  endif
	  resu._cnt(1) = resu._cnt(1) + B._cnt(1);
	  resu.ridx = [resu.ridx(:); B.ridx(:)];
	  if size(B._name{1}, 1) < B._cnt(1),
	    B._name{1} = char(B._name{1}, ...
			      repmat('', B._cnt(1)-size(B._name{1}, 1), 1));
	  endif
	  resu._name{1} = char(resu._name{1}, B._name{1});
	  %# find data with same column names
	  indr = logical(ones(1, resu.cnt(2)));
	  indb = logical(ones(1, resu.cnt(2)));
	  indi = 1;
	  while indi <= resu.cnt(2),
	    indj = strmatch(resu._name{2}(indi, :), B. _name{2});
	    if ~isempty(indj),
	      indj = indj(1);
	      if ~strcmp(resu.type{indi}, B.type{indj}),
		error("Trying to mix columns of different types");
	      endif
	      resu.data{indi} = [resu.data{indi}; B.data{indj}];
	      indr(indi) = false; indb(indj) = false;
	    endif
	    indi = indi + 1;
	  endwhile
	  if any(indr) || any(indb)
	    error('Different number/names of columns in dataframe');
	  endif
	endfor

      case 2
	resu = A;
	for indi=1:length(varargin),
	  B = varargin{indi};
	  if resu._cnt(1) != B._cnt(1),
	    error('Different number of rows in dataframes');
	  endif
	  if any(resu.ridx(:) - B.ridx(:))
	    error('dataframes row indexes not matched');
	  endif
	  resu._name{2} = char(resu._name{2}, B._name{2});
	  indj = resu.cnt(2) + 1;
	  for indi = 1:B.cnt(2),
	    resu.data{indj} = B.data{indi};
	    resu.type{indj} = B.type{indi};
	    indj = indj + 1;
	  endfor
	  resu.cnt(2) = resu.cnt(2) + B.cnt(2);	
	endfor

      otherwise
	error('Incorrect call to cat');
  endswitch

  %#  disp('End of cat'); keyboard
endfunction
