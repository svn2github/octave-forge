function [idx, nelem] = df_name2idx(names, subs, count)

  %# This is a helper routine to translate rownames or columnames into
  %# real index. Input: names, a char array, and subs, a cell array as
  %# produced by subsref and similar.

  %% Copyright (C) 2009-2010 Pascal Dupuis <Pascal.Dupuis@uclouvain.be>
  %%
  %% This file is part of Octave.
  %%
  %% Octave is free software; you can redistribute it and/or
  %% modify it under the terms of the GNU General Public
  %% License as published by the Free Software Foundation;
  %% either version 2, or (at your option) any later version.
  %%
  %% Octave is distributed in the hope that it will be useful,
  %% but WITHOUT ANY WARRANTY; without even the implied
  %% warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  %% PURPOSE.  See the GNU General Public License for more
  %% details.
  %%
  %% You should have received a copy of the GNU General Public
  %% License along with Octave; see the file COPYING.  If not,
  %% write to the Free Software Foundation, 59 Temple Place -
  %% Suite 330, Boston, MA 02111-1307, USA.
  
  %#
  %# $Id: df_name2idx.m,v 1.4 2010-07-20 17:51:31 dupuis Exp $
  %#

  idx = []; 
  if isa(subs, 'char'),
    subs = cellstr(subs);
  else
    if !isvector(subs),
      error("Trying to access column as a matrix");
    endif
    subs = subs(:);
  endif

  if isa(subs, 'cell'),
   %# translate list of variables to list of indices
    for indi= 1:size(subs, 1),
      if strcmp(subs{indi}, ':'),
	idx = [idx 1:count];
      else
	%# convert from standard pattern to regexp pattern
	subs{indi} = regexprep(subs{indi}, '([^\.])\*', "$1.*");
	for indj = 1:min(size(names, 1), count), %# sanity check
	  if ~isempty(regexp(names(indj, :), subs{indi})),
	    idx = [idx indj];
	  endif
	endfor
      endif
    endfor
  else
    idx = subs;
  endif
  if isa(subs, 'logical')
    nelem = sum(idx);
  else
    nelem = length(idx);
  endif

endfunction
